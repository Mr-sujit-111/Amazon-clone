import moment from "moment/moment";
import { getSession, useSession } from "next-auth/react";
import Header from "../components/Header"
import { stripeOrders } from "../firebase";

function orderlist({ order }) {

    const session = useSession();
    return (
        <div>
            <Header />
            <main className="mx-auto max-w-screen-2x1 p-10">
                <h1 className="text-3xl border-b mb-2 pb-1 border-yellow-400">Your Orders</h1>

                {session.data ? <p className="capitalize my-3"> Total Orders : 0</p> : <p>Sign-in to see your order</p>}

                <div className="mt-5 space-y-4"></div>
            </main>
        </div>
    )
}

export default orderlist

export async function getServerSideProps(context) {
    const stripe = require('stripe')(process.env.STRIPE_SECRET);

    // get users credentials
    const session = await getSession(context);

    if (!session) {
        return {
            props: {}
        }
    }

    stripeOrders.forEach((doc) => {
        console.log(doc.id, " => ", doc.data().amount);
    });

    // get order details from firebase
    const orders = await Promise.all(
        stripeOrders.docs.map(async (order) => ({
            id: order.id,
            amount: order.data().amount,
            images: order.data().images,
            timestamp: moment(order.data().timestamp.toDate()).unix(),
            items: (
                await stripe.checkout.sessions.listLineItems(order.id, {
                    limit: 100,
                })
            ).data,
        }))
    );

    if (!session) {
        return {
            props: {
                orders
            }
        }
    }
}