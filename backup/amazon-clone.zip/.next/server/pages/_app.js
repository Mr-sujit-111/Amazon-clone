/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ \"react-redux\");\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../store/store */ \"./store/store.js\");\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_3__.Provider, {\n        store: _store_store__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_2__.SessionProvider, {\n            session: pageProps.session,\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\projects\\\\amazon-clone\\\\pages\\\\_app.js\",\n                lineNumber: 10,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\projects\\\\amazon-clone\\\\pages\\\\_app.js\",\n            lineNumber: 9,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\projects\\\\amazon-clone\\\\pages\\\\_app.js\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUErQjtBQUNrQjtBQUNZO0FBQzFCO0FBRW5DLFNBQVNJLEtBQUssQ0FBQyxFQUFFQyxTQUFTLEdBQUVDLFNBQVMsR0FBRSxFQUFFO0lBQ3ZDLHFCQUNFLDhEQUFDSixpREFBa0I7UUFBQ0MsS0FBSyxFQUFFQSxvREFBSztrQkFDOUIsNEVBQUNILDREQUFlO1lBQUNPLE9BQU8sRUFBRUQsU0FBUyxDQUFDQyxPQUFPO3NCQUN6Qyw0RUFBQ0YsU0FBUztnQkFBRSxHQUFHQyxTQUFTOzs7OztvQkFBSTs7Ozs7Z0JBQ1o7Ozs7O1lBQ0MsQ0FDdEI7QUFDSCxDQUFDO0FBRUQsaUVBQWVGLEtBQUsiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hbWF6b24tY2xvbmUvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuaW1wb3J0IHsgU2Vzc2lvblByb3ZpZGVyIH0gZnJvbSBcIm5leHQtYXV0aC9yZWFjdFwiXG5pbXBvcnQgeyBQcm92aWRlciBhcyBSZWR1eFN0b3JlUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgc3RvcmUgZnJvbSAnLi4vc3RvcmUvc3RvcmUnO1xuXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8UmVkdXhTdG9yZVByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XG4gICAgICA8U2Vzc2lvblByb3ZpZGVyIHNlc3Npb249e3BhZ2VQcm9wcy5zZXNzaW9ufT5cbiAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgPC9TZXNzaW9uUHJvdmlkZXI+XG4gICAgPC9SZWR1eFN0b3JlUHJvdmlkZXI+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHBcbiJdLCJuYW1lcyI6WyJTZXNzaW9uUHJvdmlkZXIiLCJQcm92aWRlciIsIlJlZHV4U3RvcmVQcm92aWRlciIsInN0b3JlIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJzZXNzaW9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./store/cartSlice.js":
/*!****************************!*\
  !*** ./store/cartSlice.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"addToCart\": () => (/* binding */ addToCart),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"removeToCart\": () => (/* binding */ removeToCart),\n/* harmony export */   \"selectedItems\": () => (/* binding */ selectedItems),\n/* harmony export */   \"totalPrice\": () => (/* binding */ totalPrice)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n\nconst cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n    name: \"cart\",\n    initialState: {\n        items: [],\n        selectedItems: []\n    },\n    reducers: {\n        addToCart (state, action) {\n            state.items = [\n                ...state.items,\n                action.payload\n            ];\n        },\n        removeToCart (state, action) {\n            const index = state.items.findIndex((cartItem)=>cartItem.id === action.payload.id);\n            let updatedCartList = [\n                ...state.items\n            ];\n            if (index >= 0) {\n                updatedCartList.splice(index, 1);\n            }\n            state.items = updatedCartList;\n        },\n        addSelectedItem (state, action) {\n            state.selectedItems = action.payload;\n        }\n    }\n});\nconst { addToCart , removeToCart  } = cartSlice.actions;\nconst selectedItems = (state)=>state.items;\nconst totalPrice = (state)=>state.items.reduce((total, item)=>total + item.price, 0);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9jYXJ0U2xpY2UuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUErQztBQUUvQyxNQUFNQyxTQUFTLEdBQUdELDZEQUFXLENBQUM7SUFDMUJFLElBQUksRUFBRSxNQUFNO0lBQ1pDLFlBQVksRUFBRTtRQUNWQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsRUFBRTtLQUNwQjtJQUNEQyxRQUFRLEVBQUU7UUFDTkMsU0FBUyxFQUFDQyxLQUFLLEVBQUVDLE1BQU0sRUFBRTtZQUNyQkQsS0FBSyxDQUFDSixLQUFLLEdBQUc7bUJBQUlJLEtBQUssQ0FBQ0osS0FBSztnQkFBRUssTUFBTSxDQUFDQyxPQUFPO2FBQUMsQ0FBQztRQUNuRCxDQUFDO1FBQ0RDLFlBQVksRUFBQ0gsS0FBSyxFQUFFQyxNQUFNLEVBQUU7WUFDeEIsTUFBTUcsS0FBSyxHQUFHSixLQUFLLENBQUNKLEtBQUssQ0FBQ1MsU0FBUyxDQUFDQyxDQUFBQSxRQUFRLEdBQUlBLFFBQVEsQ0FBQ0MsRUFBRSxLQUFLTixNQUFNLENBQUNDLE9BQU8sQ0FBQ0ssRUFBRSxDQUFDO1lBRWxGLElBQUlDLGVBQWUsR0FBRzttQkFBSVIsS0FBSyxDQUFDSixLQUFLO2FBQUM7WUFFdEMsSUFBSVEsS0FBSyxJQUFJLENBQUMsRUFBRTtnQkFDWkksZUFBZSxDQUFDQyxNQUFNLENBQUNMLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNyQyxDQUFDO1lBRURKLEtBQUssQ0FBQ0osS0FBSyxHQUFHWSxlQUFlO1FBQ2pDLENBQUM7UUFDREUsZUFBZSxFQUFDVixLQUFLLEVBQUVDLE1BQU0sRUFBRTtZQUMzQkQsS0FBSyxDQUFDSCxhQUFhLEdBQUdJLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDO1FBQ3pDLENBQUM7S0FDSjtDQUNKLENBQUM7QUFFSyxNQUFNLEVBQUVILFNBQVMsR0FBRUksWUFBWSxHQUFFLEdBQUdWLFNBQVMsQ0FBQ2tCLE9BQU8sQ0FBQztBQUN0RCxNQUFNZCxhQUFhLEdBQUcsQ0FBQ0csS0FBSyxHQUFLQSxLQUFLLENBQUNKLEtBQUssQ0FBQztBQUM3QyxNQUFNZ0IsVUFBVSxHQUFHLENBQUNaLEtBQUssR0FBS0EsS0FBSyxDQUFDSixLQUFLLENBQUNpQixNQUFNLENBQUMsQ0FBQ0MsS0FBSyxFQUFFQyxJQUFJLEdBQUtELEtBQUssR0FBR0MsSUFBSSxDQUFDQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEcsaUVBQWV2QixTQUFTLENBQUN3QixPQUFPLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hbWF6b24tY2xvbmUvLi9zdG9yZS9jYXJ0U2xpY2UuanM/NWE1NyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVTbGljZSB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCI7XHJcblxyXG5jb25zdCBjYXJ0U2xpY2UgPSBjcmVhdGVTbGljZSh7XHJcbiAgICBuYW1lOiBcImNhcnRcIixcclxuICAgIGluaXRpYWxTdGF0ZToge1xyXG4gICAgICAgIGl0ZW1zOiBbXSxcclxuICAgICAgICBzZWxlY3RlZEl0ZW1zOiBbXVxyXG4gICAgfSxcclxuICAgIHJlZHVjZXJzOiB7XHJcbiAgICAgICAgYWRkVG9DYXJ0KHN0YXRlLCBhY3Rpb24pIHtcclxuICAgICAgICAgICAgc3RhdGUuaXRlbXMgPSBbLi4uc3RhdGUuaXRlbXMsIGFjdGlvbi5wYXlsb2FkXTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIHJlbW92ZVRvQ2FydChzdGF0ZSwgYWN0aW9uKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gc3RhdGUuaXRlbXMuZmluZEluZGV4KGNhcnRJdGVtID0+IGNhcnRJdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZC5pZCk7XHJcblxyXG4gICAgICAgICAgICBsZXQgdXBkYXRlZENhcnRMaXN0ID0gWy4uLnN0YXRlLml0ZW1zXTtcclxuXHJcbiAgICAgICAgICAgIGlmIChpbmRleCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQ2FydExpc3Quc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgc3RhdGUuaXRlbXMgPSB1cGRhdGVkQ2FydExpc3RcclxuICAgICAgICB9LFxyXG4gICAgICAgIGFkZFNlbGVjdGVkSXRlbShzdGF0ZSwgYWN0aW9uKSB7XHJcbiAgICAgICAgICAgIHN0YXRlLnNlbGVjdGVkSXRlbXMgPSBhY3Rpb24ucGF5bG9hZDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG59KTtcclxuXHJcbmV4cG9ydCBjb25zdCB7IGFkZFRvQ2FydCwgcmVtb3ZlVG9DYXJ0IH0gPSBjYXJ0U2xpY2UuYWN0aW9ucztcclxuZXhwb3J0IGNvbnN0IHNlbGVjdGVkSXRlbXMgPSAoc3RhdGUpID0+IHN0YXRlLml0ZW1zO1xyXG5leHBvcnQgY29uc3QgdG90YWxQcmljZSA9IChzdGF0ZSkgPT4gc3RhdGUuaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnByaWNlLCAwKTtcclxuZXhwb3J0IGRlZmF1bHQgY2FydFNsaWNlLnJlZHVjZXI7XHJcbiJdLCJuYW1lcyI6WyJjcmVhdGVTbGljZSIsImNhcnRTbGljZSIsIm5hbWUiLCJpbml0aWFsU3RhdGUiLCJpdGVtcyIsInNlbGVjdGVkSXRlbXMiLCJyZWR1Y2VycyIsImFkZFRvQ2FydCIsInN0YXRlIiwiYWN0aW9uIiwicGF5bG9hZCIsInJlbW92ZVRvQ2FydCIsImluZGV4IiwiZmluZEluZGV4IiwiY2FydEl0ZW0iLCJpZCIsInVwZGF0ZWRDYXJ0TGlzdCIsInNwbGljZSIsImFkZFNlbGVjdGVkSXRlbSIsImFjdGlvbnMiLCJ0b3RhbFByaWNlIiwicmVkdWNlIiwidG90YWwiLCJpdGVtIiwicHJpY2UiLCJyZWR1Y2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./store/cartSlice.js\n");

/***/ }),

/***/ "./store/store.js":
/*!************************!*\
  !*** ./store/store.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _cartSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cartSlice */ \"./store/cartSlice.js\");\n\n\nconst store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n    reducer: _cartSlice__WEBPACK_IMPORTED_MODULE_1__[\"default\"]\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9zdG9yZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWlEO0FBQ2Q7QUFFbkMsTUFBTUUsS0FBSyxHQUFHRixnRUFBYyxDQUFDO0lBQ3pCRyxPQUFPLEVBQUVGLGtEQUFTO0NBQ3JCLENBQUM7QUFFRixpRUFBZUMsS0FBSyIsInNvdXJjZXMiOlsid2VicGFjazovL2FtYXpvbi1jbG9uZS8uL3N0b3JlL3N0b3JlLmpzPzM2NjMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY29uZmlndXJlU3RvcmUgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0J1xyXG5pbXBvcnQgY2FydFNsaWNlIGZyb20gJy4vY2FydFNsaWNlJ1xyXG5cclxuY29uc3Qgc3RvcmUgPSBjb25maWd1cmVTdG9yZSh7XHJcbiAgICByZWR1Y2VyOiBjYXJ0U2xpY2UsXHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBzdG9yZSJdLCJuYW1lcyI6WyJjb25maWd1cmVTdG9yZSIsImNhcnRTbGljZSIsInN0b3JlIiwicmVkdWNlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./store/store.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();