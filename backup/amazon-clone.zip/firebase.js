import { initializeApp } from "firebase/app";
import { collection, doc, getDoc, getDocFromCache, getDocs, getFirestore, query } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAYTGRmCJPIOGx-Pz_M30leTA9A4AoYiR8",
    authDomain: "clone-8dee6.firebaseapp.com",
    projectId: "clone-8dee6",
    storageBucket: "clone-8dee6.appspot.com",
    messagingSenderId: "166760123042",
    appId: "1:166760123042:web:2918120e42c0c1e618a5fb"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

export const users = collection(db, "users");

const docRef = doc(db, "users", "sbhanderi11@gmail.com");
const docSnap = await getDoc(docRef);
const q = query(collection(db, "users"));
export const stripeOrders = await getDocs(q);
/* querySnapshot.forEach((doc) => {
    console.log(doc.id, " => ", doc.data());
}); */