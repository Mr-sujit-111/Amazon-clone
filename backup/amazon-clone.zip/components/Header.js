import Image from "next/image"
import AmazonLogo from "../assets/images/amazon-logo.png";
import { InboxIcon, ShoppingCartIcon, MoonIcon } from '@heroicons/react/24/outline'
import { useSession, signIn, signOut } from "next-auth/react"
import { useRouter } from "next/router";
import { useSelector } from "react-redux";
import { selectedItems } from "../store/cartSlice";
function Header() {
    const session = useSession();
    const route = useRouter();
    const items = useSelector(selectedItems);
    return (
        <div>
            <div className="bg-[#131921]  p-3 flex">
                {/* icon-logo */}
                <div className="flex items-center flex-grow sm:flex-grow-0 pt-2 pr-2">
                    <Image src={AmazonLogo}
                        onClick={() => route.push("/")}
                        width={150}
                        height={40}
                        className="cursor-pointer"
                    />
                </div>
                {/* searchbar */}
                <div className="hidden sm:flex bg-yellow-400  flex-grow rounded-md cursor-pointer">
                    <input className="flex flex-grow rounded-l-md focus:outline-none p-3" type="text" name="" id="" />
                    <div className="icon h-10 w-11 p-2">
                        <InboxIcon />
                    </div>
                </div>
                {/* right section */}
                <div className="flex gap-3 mx-3 text-white text-md">
                    <div className="mx-3" onClick={session.data ? signOut : signIn}>
                        {session.data ? <p>Hello, {session.data.user.name}</p> : "Sign-in"}
                        <p className="font-bold whitespace-pre hover:link">Account & Lists</p>
                    </div>
                    <div className="mx-3">
                        <p>Returns</p>
                        <p className="font-bold whitespace-pre hover:link">& Orders</p>
                    </div>
                    <div className="mx-3 flex justify-center items-center gap-2 relative cursor-pointer" onClick={() => route.push("/checkout")}>
                        <span className="absolute bg-yellow-500 w-6  h-5 flex justify-center items-center rounded-full top-0 left-7 text-black font-bold">{items.length}</span>
                        <div>
                            <ShoppingCartIcon height={40} />
                        </div>
                        <p className="font-bold whitespace-pre hover:link hidden sm:inline ">Cart</p>
                    </div>
                </div>
            </div>
            {/* second navbar */}
            <div className="bg-[#232F3E] text-white space-x-4 flex items-center p-3">
                <div className="flex items-center">
                    <MoonIcon height={40} />
                    <p>All</p>
                </div>
                <p className="whitespace-nowrap hover:link font-bold">Sell</p>
                <p className="whitespace-nowrap hover:link font-bold">Best Seller</p>
                <p className="whitespace-nowrap hover:link font-bold">Today's Deal</p>
                <p className="whitespace-nowrap hover:link hidden sm:inline-block font-bold">Customer Service</p>
                <p className="whitespace-nowrap hover:link hidden sm:inline-block font-bold">Electronics</p>
                <p className="whitespace-nowrap hover:link hidden sm:inline-block font-bold">Books</p>
                <p className="whitespace-nowrap hover:link hidden md:inline-block font-bold">home & kichen</p>
                <p className="whitespace-nowrap hover:link hidden lg:inline-block font-bold">Computers</p>
                <p className="whitespace-nowrap hover:link hidden lg:inline-block font-bold">Fashion</p>
                <p className="whitespace-nowrap hover:link hidden lg:inline-block font-bold">Mobiles</p>
            </div>
        </div>
    )
}

export default Header