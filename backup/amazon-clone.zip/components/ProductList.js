import ProductItem from "./ProductItem"

function ProductList({ products }) {
    return (
        <div className="grid grid-flow-row-dense md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 md:-mt-52">
            {products.slice(0, 4).map(({ title, price, description, category, image }, index) => (
                <ProductItem key={index}
                    title={title}
                    price={price}
                    description={description}
                    category={category}
                    img={image} />
            ))}
            <img className="md:col-span-full" src="https://links.papareact.com/dyz" alt="" />
            <div className="md:col-span-2">
                {products.slice(4, 5).map(({ id, title, price, description, category, image }, index) => (
                    <ProductItem key={index}
                        title={title}
                        price={price}
                        description={description}
                        category={category}
                        img={image}
                        id={id} />
                ))}
            </div>
            {products.slice(5, products.length - 1).map(({ title, price, description, category, image }, index) => (
                <ProductItem key={index}
                    title={title}
                    price={price}
                    description={description}
                    category={category}
                    img={image} />
            ))}
        </div>
    )
}

export default ProductList